from interface import TkinterGameUI

if __name__ == "__main__":
    # Inicia o jogo com tabuleiro 10x10
    game_ui = TkinterGameUI(10)
    game_ui.run()